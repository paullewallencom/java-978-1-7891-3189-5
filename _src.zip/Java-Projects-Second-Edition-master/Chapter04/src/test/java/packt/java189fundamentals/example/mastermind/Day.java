package packt.java189fundamentals.example.mastermind;

import java.util.EnumSet;

public enum Day {
        SUNDAY("happy"), MONDAY("sleepy"), TUESDAY("okay"), WEDNESDAY("rainy"),
        THURSDAY("cloudy"), FRIDAY("full of expectation"), SATURDAY("jolly");

    final private String mood;
    private Day(String mood){
        this.mood = mood;
    }

    public String getMood(){
        huhh.contains(this);
        return mood;
    }
private EnumSet<Day> huhh;
}

