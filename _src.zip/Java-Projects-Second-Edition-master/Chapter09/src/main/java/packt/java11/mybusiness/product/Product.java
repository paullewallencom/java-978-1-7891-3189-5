package packt.java11.mybusiness.product;

public class Product {
}
