// START SNIPPET ColorFactory_ch05
package packt.java189fundamentals.mastermind;

public interface ColorFactory {
    Color newColor();
}
//END SNIPPET