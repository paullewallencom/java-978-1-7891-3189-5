package packt.java189fundamentals.mastermind.integration;

public interface Player {
    void play();
}
