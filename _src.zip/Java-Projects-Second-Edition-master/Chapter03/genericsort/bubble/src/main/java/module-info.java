module bubble {
    exports packt.java189fundamentals.ch03.main.bubble;
    exports packt.java189fundamentals.ch03.main.bubble.generic;
    requires packt.java189fundamentals.SortInterface;
}