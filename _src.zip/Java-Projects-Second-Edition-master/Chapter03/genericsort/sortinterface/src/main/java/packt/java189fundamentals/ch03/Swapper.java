package packt.java189fundamentals.ch03;

// START SNIPPET interface_Swapper
public interface Swapper {
    void swap(int i, int j);
}
// END SNIPPET