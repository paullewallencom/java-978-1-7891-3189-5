package packt.java189fundamentals.ch03;

// START SNIPPET interface_Sortable
public interface Sortable {
    Object get(int i);
    int size();
}
// END SNIPPET