module packt.java189fundamentals.SortSupportClasses {
    requires packt.java189fundamentals.SortInterface;
    exports packt.java189fundamentals.ch03.support;
}