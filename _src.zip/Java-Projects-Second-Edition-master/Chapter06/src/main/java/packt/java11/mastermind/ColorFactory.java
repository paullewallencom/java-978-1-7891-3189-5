package packt.java11.mastermind;

public interface ColorFactory {
    Color newColor();
}
